
import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

import quizData from "../../public/green_talent_quiz_25.json";

export default function GreenTalentQuizApp() {
  const [current, setCurrent] = useState(0);
  const [selected, setSelected] = useState(null);
  const [showAnswer, setShowAnswer] = useState(false);
  const [score, setScore] = useState(0);
  const [answered, setAnswered] = useState(Array(quizData.length).fill(false));

  const question = quizData[current];
  const total = quizData.length;

  const handleOptionClick = (index) => {
    setSelected(index);
    setShowAnswer(true);
    if (index === question.answer && !answered[current]) {
      setScore(score + 1);
    }
    const updated = [...answered];
    updated[current] = true;
    setAnswered(updated);
  };

  const handleNext = () => {
    setCurrent((prev) => (prev + 1) % total);
    setSelected(null);
    setShowAnswer(false);
  };

  const progressPercent = ((answered.filter(Boolean).length) / total) * 100;

  return (
    <div className="max-w-3xl mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">環境部淨零綠領人才｜模擬題庫練習</h1>

      <div className="mb-4">
        <div className="w-full bg-gray-200 rounded-full h-4">
          <div
            className="bg-green-500 h-4 rounded-full"
            style={{ width: `${progressPercent}%` }}
          ></div>
        </div>
        <p className="text-sm text-right mt-1 text-gray-600">
          完成題數：{answered.filter(Boolean).length}/{total} ｜ 得分：{score}
        </p>
      </div>

      <Card>
        <CardContent className="space-y-4 p-6">
          <p className="text-lg font-semibold">
            第 {current + 1} 題：{question.question}
          </p>
          <ul className="space-y-2">
            {question.options.map((opt, idx) => (
              <li key={idx}>
                <Button
                  variant="outline"
                  className={`w-full text-left ${
                    showAnswer
                      ? idx === question.answer
                        ? "border-green-600 text-green-700"
                        : idx === selected
                        ? "border-red-500 text-red-600"
                        : ""
                      : ""
                  }`}
                  onClick={() => handleOptionClick(idx)}
                  disabled={showAnswer}
                >
                  {String.fromCharCode(65 + idx)}. {opt}
                </Button>
              </li>
            ))}
          </ul>

          {showAnswer && (
            <div className="mt-4 p-4 bg-gray-100 rounded-md">
              <p className="font-medium text-green-700">✅ 正確答案：{String.fromCharCode(65 + question.answer)}</p>
              <p className="text-sm mt-1 text-gray-700">出處：{question.explanation}</p>
            </div>
          )}

          <div className="pt-6 text-right">
            <Button onClick={handleNext}>下一題</Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
