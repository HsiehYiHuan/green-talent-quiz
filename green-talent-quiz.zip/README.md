# Green Talent Quiz 題庫系統

此專案提供互動式題庫網站，支援 GitHub Pages 部署。

## 🛠 安裝

```bash
npm install
```

## 🚀 本地開發

```bash
npm run dev
```

## 📦 打包與部署到 GitHub Pages

```bash
npm run build
npm run deploy
```

## 📍 GitHub Pages 預設部署路徑

https://HsiehYiHuan.github.io/green-talent-quiz/
